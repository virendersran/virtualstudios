package com.takeoffandroid.multipleviewinrecycleview;

/**
 * Created by Administrator on 30/06/2015.
 */
public class Generic {

    private String name;

    public Generic (){}

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


}
