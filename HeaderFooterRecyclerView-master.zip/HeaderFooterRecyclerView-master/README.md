# HeaderFooterRecyclerView


This repo is nothing but creating a separate header and footer layout for RecyclerView.

For tutorials please visit by blog

http://takeoffandroid.com/uncategorized/header-and-footer-layout-for-recylerview/  
