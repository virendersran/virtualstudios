package com.journaldev.swipeviewpagerinshorts;


/**
 * Created by anupamchugh on 28/02/18.
 */

public class DataModel {

    public String title, description, url;

    public DataModel(String title, String description, String url) {
        this.title = title;
        this.description = description;
        this.url = url;
    }
}
